Gurkan Kilicaslan	
5810725		
kilia064@umn.edu

Project Final

Python 3.9.13


You need to install h5py, numpy, matplotlib, and seaborn in order to run this code.
pip install h5py
pip install numpy
pip install matplotlib
pip install seaborn


How to run:
Put "advanced_ML_project_FINAL.py" and "data.h5" in the same direction. Then, run "advanced_ML_project_FINAL.py".
It will ask you to choose the network that you want to use:
1 for RNN
2 for LSTM
3 for GRU,
Anything else to exit.

