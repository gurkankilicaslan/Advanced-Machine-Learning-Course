import numpy as np

class MySVM:

    def __init__(self, d, max_iters, eta_val, c):

    def fit(self, X, y):

    def predict(self, X):
