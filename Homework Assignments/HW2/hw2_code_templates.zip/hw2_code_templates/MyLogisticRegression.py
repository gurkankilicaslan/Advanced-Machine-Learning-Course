import numpy as np

class MyLogisticRegression:

    def __init__(self, d, max_iters, eta_val):

    def fit(self, X, y):

    def predict(self, X):
