Gurkan Kilicaslan	
5810725		
kilia064@umn.edu

HW2

Python 3.9.13

I used my "my_cross_val.py" from HW1 and slightly changed it. Please find the new version in uploaded files.


How to run:
Put all the .py files and hw2_q2_q4_dataset.csv in the same direction. Then, run hw2_q2.py, and hw2_q4.py respectively.
