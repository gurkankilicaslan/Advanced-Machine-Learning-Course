Gurkan Kilicaslan	
5810725		
kilia064@umn.edu

HW3

Python 3.9.13

Libraries described in hw3.pdf are required

How to run:
Put all the .py file in the same direction. Then, run hw3_q2.py, and hw3_q3.py respectively.

