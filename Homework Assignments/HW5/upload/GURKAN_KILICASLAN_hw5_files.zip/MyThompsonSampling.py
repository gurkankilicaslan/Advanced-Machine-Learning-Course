import numpy as np

class MyThompsonSampling:
    def __init__(self, num_arms):
        number = num_arms
        self.num_arms = number
        good = []
        bad = []
        for i in range(number):
            good.append(1)
            bad.append(1)
        
        good = np.array(good)
        bad = np.array(bad)
            
        self.good = good
        self.bad = bad

    def pull_arm(self):
        import random
        
        theta = [random.betavariate(i,j) for i,j in zip(self.good, self.bad)]
        
        pullarm = theta.index(max(theta))
        
        self.pullarm = pullarm 
        return self.pullarm

    def update_model(self, reward):
        a = self.pullarm
        if reward == True:
            self.good[a] = self.good[a] + 1

        else: 
            self.bad[a] = self.bad[a] + 1