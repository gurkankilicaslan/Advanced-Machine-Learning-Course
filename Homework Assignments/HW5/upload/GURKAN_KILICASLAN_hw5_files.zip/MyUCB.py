import numpy as np

class MyUCB:
    def __init__(self, num_arms):
        
        number = num_arms
             
        self.num_arms = number
        self.createEmpty = np.zeros(number)
        self.addMany = np.zeros(number)
        
        self.count = 0

    def pull_arm(self):
        if self.num_arms > self.count:
            
            armbef = []
            for i in range(self.num_arms):
                armbef.append(i)
            
            armbef = np.array(armbef)
            
            pullarm = armbef[self.count]
            
            self.pullarm = pullarm
            
            self.addMany[pullarm] = self.addMany[pullarm] + 1
            self.count = self.count + 1
            
            return self.pullarm
        else:
            upci = self.createEmpty + (2*np.log(self.count)/(self.addMany))**(0.5)
            # print(upci)
            # pullarm = 0
            # for i in range(len(upci)):
            #     if i>0:
            #         if upci[i] > upci[i-1]:
            #             pullarm = i
            
            upciList = upci.tolist()
            pullarm = upciList.index(max(upciList))
            
            self.pullarm = pullarm
            
            self.addMany[pullarm] = self.addMany[pullarm] + 1
            self.count = self.count + 1
            
            return self.pullarm

    def update_model(self, reward):
        a = self.pullarm
        self.createEmpty[a] = (self.createEmpty[a]*self.addMany[a] + reward)/(self.addMany[a]+1)
        self.addMany[self.pullarm] += 1
        
        
        
        