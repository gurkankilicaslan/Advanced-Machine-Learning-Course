Gurkan Kilicaslan	
5810725		
kilia064@umn.edu

HW5

Python 3.9.13



How to run:
Put all the .py file in the same direction. Then, run hw5_q4.py.

