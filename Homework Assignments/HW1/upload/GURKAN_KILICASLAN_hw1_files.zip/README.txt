Gurkan Kilicaslan	
5810725		
kilia064@umn.edu


Python 3.9.13

Libraries used in my_cross_val.py: numpy, random, pandas


How to run:
Put all the .py files and hw1_q5_dataset.csv in the same direction. Then, run hw1_q3.py, hw1_q4.py, and hw1_q5.py respectively.
