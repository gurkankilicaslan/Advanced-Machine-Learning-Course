import numpy as np

def my_cross_val(model, loss_func, X, y, k=10):

