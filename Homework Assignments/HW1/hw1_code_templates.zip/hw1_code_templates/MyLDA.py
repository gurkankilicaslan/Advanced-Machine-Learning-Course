import numpy as np

class MyLDA():

    def __init__(self, lambda_val):

    def fit(self, X, y):

    def predict(self, X):

