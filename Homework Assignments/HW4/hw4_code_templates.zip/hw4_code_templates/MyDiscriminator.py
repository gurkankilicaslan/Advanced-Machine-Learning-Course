import numpy as np

import torch
import torch.nn as nn

class MyDiscriminator(nn.Module):
