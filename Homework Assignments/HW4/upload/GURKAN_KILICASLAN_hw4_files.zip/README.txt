Gurkan Kilicaslan	
5810725		
kilia064@umn.edu

HW4

Python 3.9.13



How to run:
Put all the .py file in the same direction. Then, run hw4_q1.py, hw4_q2.py, and hw4_q3.py respectively.

